const cryptoJs = require('crypto-js');
const on = cryptoJs.SHA256("sdfjh2hu3u92873883YUIY3U").toString();
module.exports = on;